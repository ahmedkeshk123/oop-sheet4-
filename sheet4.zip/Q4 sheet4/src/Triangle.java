public class Triangle extends GeometricObject
{
    private double side;
    private double side1;
    private double side2;

    public Triangle (double side , double side1 , double side2 , String color , boolean filled)
    {
        super(color, filled);
        this.side=side;
        this.side1=side1;
        this.side2=side2;
    }

    public double getSide()
    {
        return side;
    }

    public void setSide(double side)
    {
        this.side = side;
    }

    public double getSide1()
    {
        return side1;
    }

    public void setSide1(double side1)
    {
        this.side1 = side1;
    }

    public double getSide2()
    {
        return side2;
    }

    public void setSide2(double side2)
    {
        this.side2 = side2;
    }
    @Override
    public String toString() {
        return "Triangle{" +
                "side=" + side +
                ", side1=" + side1 +
                ", side2=" + side2 +
                '}';
    }
    public double getArea() {
        double res = (side+side1+side2)/2;
        return Math.sqrt(res * (res - side) * (res - side1) * (res - side2));
    }


    @Override
    public double getPerimeter() {
        return side+side1+side2;
    }
}
